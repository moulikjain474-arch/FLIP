import os, zipfile, collections, glob
S = '/scratch'
ROOTS = [(S + '/flip_out', 'flip_out'), (S + '/flip/results_08Oct', 'results_08Oct'), (S + '/union_tmp', 'union_combined'), (S + '/flip/results', 'flip_results_dir'), (S + '/flip/docs', 'flip_docs')]
OUT = '/shared-docker/flip_results_final.zip'
NOT = ('.bin', '.safetensors', '.gguf', '.ckpt', '.pth', '.onnx')
SKIP = ('hub', 'hf_cache', '__pycache__', '.git', 'models--', 'blobs')
disk, excl, big, skipped = {}, collections.Counter(), [], collections.Counter()
for r, name in ROOTS:
    for d, ds, fs in os.walk(r):
        ds[:] = [x for x in ds if not any(s in x for s in SKIP)]
        for f in fs:
            p = os.path.join(d, f)
            if os.path.islink(p) or not os.path.isfile(p):
                continue
            arc = name + '/' + os.path.relpath(p, r)
            if f.endswith(NOT):
                excl[os.path.splitext(f)[1]] += 1; continue
            if os.path.getsize(p) > 50e6:
                big.append(arc); continue
            disk[arc] = p
for f in sorted(os.listdir(S + '/flip')):
    p = os.path.join(S + '/flip', f)
    if os.path.isfile(p) and f.endswith(('.py', '.sh', '.md', '.txt')) and os.path.getsize(p) < 5e6:
        disk['node_scripts/' + f] = p
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for arc, p in disk.items():
        z.write(p, arc)
zf = zipfile.ZipFile(OUT)
names = set(zf.namelist())
print('ZIP:', OUT, '%.1f MB' % (os.path.getsize(OUT) / 1e6), '|', len(names), 'entries | corrupt entry:', zf.testzip())
print('on disk (kept):', len(disk), '| missing from zip:', len([a for a in disk if a not in names]))
print('excluded weights-like files:', dict(excl), '| over 50MB skipped:', big[:5])
need = ['flip_out/score_union_final.txt', 'flip_out/all_reports.txt', 'flip_out/earlymind_union.csv', 'flip_out/stability_table.csv', 'flip_out/fullday/perturb_seed1_families/Mistral-7B-v0.1__main__seed1.json', 'results_08Oct/paper_numbers.txt', 'node_scripts/score_new.py', 'node_scripts/perturb_test.py']
print('MISSING key files:', [k for k in need if k not in names])
logs = ['flip_out/' + os.path.basename(g) for g in glob.glob(S + '/flip_out/log_*.txt')]
print('logs in zip: %d of %d' % (len([l for l in logs if l in names]), len(logs)))
cnt = collections.Counter(n.split('/')[1] for n in names if n.startswith('union_combined/') and n.count('/') >= 2)
want = ['swap', 'position', 'perturb', 'perturb_seed1', 'perturb_seed1_families', 'uncertainty', 'steer_layers', 'code', 'benchmark', 'benchmark_arc', 'position_interleaved', 'ladder', 'ladder_probe', 'ladder_s1', 'onset_410m_seeds', 'plant_rand', 'patch', 'head_patch', 'component_patch', 'headpad', 'attention', 'story_med', 'story_med_deep', 'perturb_olmo_traj', 'position_olmo', 'ood_check', 'digits', 'decomp', 'noise', 'seed_steer', 'chain_probe']
print('EMPTY or absent result folders:', [w for w in want if cnt.get(w, 0) == 0])
print('files per folder:', ' '.join('%s=%d' % (k, v) for k, v in sorted(cnt.items())))
print('other top-level dirs in /scratch:', [e for e in os.listdir(S) if e not in ('flip', 'flip_out', 'union_tmp') and not e.startswith('hf_cache')])
