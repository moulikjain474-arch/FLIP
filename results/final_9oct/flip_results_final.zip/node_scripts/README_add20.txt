node_add20: four small tools (all exploratory, added 9 Oct after results were seen; none is a registered claim)

ood_check.py            are planted states inside the natural range?   Node (needs the 6.9B model):
  export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache; cd /scratch/flip && python3 ood_check.py --model EleutherAI/pythia-6.9b --step 143000 --task vartrack_d1 --layer 22 --out $PERSIST/fullday/ood_check
  (then the same with --task vartrack_d3). Selftest: python3 ood_check.py --selftest
error_catch_baseline.py does disagreement beat a trivial no-model predictor?   Node or Mac (needs tasks.py and the perturb JSONs):
  cd /scratch/flip && python3 error_catch_baseline.py --dir /scratch/union
  Selftest: python3 error_catch_baseline.py --selftest
tidy_repo.py            dry run by default. Mac, repo root:  python3 tidy_repo.py --root .   then add --apply
list_runners.py         Mac, repo root:  python3 list_runners.py --root . > RUNNERS.md
