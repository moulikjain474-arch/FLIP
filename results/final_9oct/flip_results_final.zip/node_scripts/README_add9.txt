node_add9 (extract into /scratch/flip):
  plant_normmatch.py   norm-matched random plant control
  seed_predict.py      do early 410M checkpoints predict the final order effect
  stability_table.py   one table: order effect across every setting (no GPU)
  run_step0.sh         random-init (step0) baselines for chain + value probes

Selftests:  python3 plant_normmatch.py --selftest && python3 seed_predict.py --selftest && python3 stability_table.py
Run:        see chat steps (run_step0.sh and plant_normmatch.py in background; seed_predict and stability_table are quick)
