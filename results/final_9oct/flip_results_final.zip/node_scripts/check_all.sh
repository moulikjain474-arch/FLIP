#!/usr/bin/env bash
# One command: progress, failures and what is still running, across every queue.
P=${PERSIST:-/scratch/flip_out}
for f in extra2 value_probe early olmo olmo_fix step0 extra3; do
  [ -f $P/log_$f.txt ] || continue
  echo "##### $f   (last line: $(tail -n 1 $P/log_$f.txt | cut -c1-110))"
  grep -E "^=== |FAILED|Traceback|Error" $P/log_$f.txt | tail -n 4 | cut -c1-140
done
echo "##### running now"
pgrep -af "run_|python3" | grep -v pgrep | cut -c1-130
echo "##### disk (/scratch)"
df -h /scratch | tail -n 1
