"""Does the Order-Flip disagreement flag beat a trivial no-model baseline? (audit A9, exploratory, added 9 Oct after results were seen)

error_catch.py shows that flagging questions where the original and swapped orders disagree catches many of the original-order errors.
That could still be unimpressive if a trivial predictor does as well, for example one that only looks at how long the prompt is or
which answer digit is correct. This script builds that predictor from item features that need no model (prompt length, number of
lines, number of '=' signs, answer index) with a ridge logistic regression, scored out-of-fold (5-fold), and lets it flag exactly as
many questions as the disagreement rule flagged (same review budget). It then compares, per model and depth:
  caught     share of original-order errors that are flagged
  precision  share of flagged questions that really were errors
with a paired bootstrap 95% interval for the difference (disagreement minus baseline) in caught. Also prints the lift over flagging at random.
The item features come from re-building the questions with the same n, seed and layout as perturb_test.py (so rows line up);
rows that cannot be matched are skipped and reported. A stronger no-internals baseline (the model's own confidence) is NOT tested here.

  python3 error_catch_baseline.py --dir results_08Oct/merged
  python3 error_catch_baseline.py --selftest
"""
import argparse
import glob
import json
import os

import numpy as np


def features(items):
    rows = []
    for it in items:
        p = it["prompt"]
        rows.append([len(p), p.count("\n"), p.count("="), int(it["label"])])
    X = np.array(rows, float)
    n_cls = int(X[:, 3].max()) + 1 if len(X) else 1
    onehot = np.eye(max(n_cls, 10))[X[:, 3].astype(int)]
    Z = X[:, :3]
    Z = (Z - Z.mean(0)) / np.where(Z.std(0) > 0, Z.std(0), 1.0)
    return np.hstack([Z, onehot])


def fit_logit(X, y, l2=3.0, iters=30):
    Xb = np.hstack([X, np.ones((len(X), 1))])
    w = np.zeros(Xb.shape[1])
    R = l2 * np.eye(Xb.shape[1]); R[-1, -1] = 0.0
    for _ in range(iters):
        p = 1 / (1 + np.exp(-np.clip(Xb @ w, -30, 30)))
        g = Xb.T @ (p - y) + R @ w
        H = (Xb * (p * (1 - p))[:, None]).T @ Xb + R + 1e-6 * np.eye(Xb.shape[1])
        w = w - np.linalg.solve(H, g)
    return w


def oof_risk(X, y, folds=5, seed=0):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(y))
    risk = np.zeros(len(y))
    for f in range(folds):
        te = idx[f::folds]
        tr = np.setdiff1d(idx, te)
        w = fit_logit(X[tr], y[tr].astype(float))
        risk[te] = np.hstack([X[te], np.ones((len(te), 1))]) @ w
    return risk


def compare(wrong, flag, X, B=2000, seed=0):
    wrong, flag = np.asarray(wrong, bool), np.asarray(flag, bool)
    k = int(flag.sum())
    if wrong.sum() == 0 or k == 0:
        return None
    risk = oof_risk(X, wrong)
    base = np.zeros(len(wrong), bool)
    base[np.argsort(-risk)[:k]] = True
    caught = lambda f, w: (f & w).sum() / max(w.sum(), 1)
    rng = np.random.default_rng(seed)
    diffs = []
    for _ in range(B):
        b = rng.integers(0, len(wrong), len(wrong))
        diffs.append(caught(flag[b], wrong[b]) - caught(base[b], wrong[b]))
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return dict(wrong=float(wrong.mean()), flagged=float(flag.mean()),
                caught_disagree=float(caught(flag, wrong)), caught_baseline=float(caught(base, wrong)),
                precision_disagree=float((flag & wrong).sum() / k), precision_baseline=float((base & wrong).sum() / k),
                lift_disagree=float((flag & wrong).sum() / k / wrong.mean()),
                diff_caught=float(caught(flag, wrong) - caught(base, wrong)), diff_ci95=[float(lo), float(hi)])


def selftest():
    rng = np.random.default_rng(0)
    n = 600
    items = [dict(prompt="x" * int(rng.integers(50, 200)) + "\n" * int(rng.integers(0, 5)), label=int(rng.integers(0, 10))) for _ in range(n)]
    X = features(items)
    L = np.array([len(it["prompt"]) for it in items], float)
    # A: errors driven by prompt length only -> the trivial baseline should do well, disagreement is pure noise
    wrongA = rng.random(n) < 1 / (1 + np.exp(-(L - L.mean()) / 15))
    flagA = rng.random(n) < 0.3
    a = compare(wrongA, flagA, X)
    # B: errors independent of the features, disagreement tracks them -> disagreement should win
    wrongB = rng.random(n) < 0.3
    flagB = wrongB & (rng.random(n) < 0.7) | (~wrongB & (rng.random(n) < 0.1))
    b = compare(wrongB, flagB, X)
    assert a["diff_ci95"][1] < 0.0 or a["diff_caught"] < 0.05, a
    assert b["diff_ci95"][0] > 0.0, b
    print("error_catch_baseline selftest ok (baseline wins when features matter; disagreement wins when they do not)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.dir:
        raise SystemExit("give --dir")
    from tasks import build_all
    print("model | depth | wrong | flagged | caught: disagreement vs baseline (diff, 95% CI) | precision: disagreement vs baseline | lift")
    cache = {}
    for f in sorted(glob.glob(os.path.join(a.dir, "perturb", "*.json"))):
        d = json.load(open(f))
        if str(d.get("revision")) not in ("main", "step143000"):
            continue
        for t, v in d["tasks"].items():
            c = v["correct"]
            o, s = np.array(c["orig"], bool), np.array(c["swap"], bool)
            flag = (o != s) if "same_answer" not in v else ~np.array(v["same_answer"], bool)
            key = (len(o), d.get("seed", 0))
            if key not in cache:
                cache[key] = build_all(key[0], key[1], shots=2, layout="blocked")
            items = cache[key].get(t)
            name = f"{d['model'].split('/')[-1]:24s} {t[-2:]}"
            if items is None or len(items) != len(o):
                print(name, "SKIPPED (items could not be matched to the stored rows)")
                continue
            r = compare(~o, flag, features(items))
            if r is None:
                print(name, "SKIPPED (no errors or nothing flagged)")
                continue
            print(f"{name}  {r['wrong']:5.1%} {r['flagged']:6.1%}  {r['caught_disagree']:5.1%} vs {r['caught_baseline']:5.1%} "
                  f"({r['diff_caught']:+.3f} [{r['diff_ci95'][0]:+.3f},{r['diff_ci95'][1]:+.3f}])  "
                  f"{r['precision_disagree']:5.1%} vs {r['precision_baseline']:5.1%}  lift {r['lift_disagree']:.2f}")


if __name__ == "__main__":
    main()
