"""Which attention heads carry the order-dependent choice? Per-head activation patching (audit A6, exploratory).

component_patch.py swaps a whole attention sublayer. Here ONE head's contribution at the last token is swapped: the
per-head slice of the attention output just before the output projection. For each question we run the order-swapped
prompt and record those slices, then run the original prompt with one head's slice replaced. Over questions where the
two orders give different answers:
  transfer = share whose patched answer equals the swapped-order answer
Reported per (layer, head), plus for each layer the 5 best heads patched together. Single heads often move little
because other heads cover for them, so a flat map is a result too (the choice is spread out), not a failure.

  python3 head_patch.py --model EleutherAI/pythia-6.9b --step 143000 --layers 12 16 20 24 28 32
  python3 head_patch.py --selftest      # tiny random models on CPU: checks the machinery
"""
import argparse
import contextlib
import json
import os

import numpy as np


def out_proj(layer):
    """The attention output projection of a block (GPT-NeoX/Pythia: attention.dense; Llama-style: self_attn.o_proj)."""
    for a, b in (("attention", "dense"), ("self_attn", "o_proj"), ("attn", "c_proj")):
        if hasattr(layer, a) and hasattr(getattr(layer, a), b):
            return getattr(getattr(layer, a), b)
    raise ValueError("unknown block layout: no attention output projection found")


@contextlib.contextmanager
def head_hooks(model, n_heads, read=(), edit=None):
    """read: iterable of layers (1..n) whose last-token pre-projection vector [B, H*hd] is recorded (float32, cpu).
    edit: {layer: (heads, tensor [B, H*hd])}: those heads' slices of the last token are replaced by the tensor's."""
    import model_utils as mu
    blocks = mu.get_layers(model)
    edit = edit or {}
    layers = set(read) | set(edit)
    store, handles = {}, []

    def make(l):
        def pre(_module, args):
            x = args[0]
            if l in read:
                store[l] = x[:, -1, :].float().cpu()
            if l in edit:
                heads, src = edit[l]
                hd = x.shape[-1] // n_heads
                x = x.clone()
                for h in heads:
                    x[:, -1, h * hd:(h + 1) * hd] = src[:, h * hd:(h + 1) * hd].to(x.device, x.dtype)
                return (x,) + tuple(args[1:])
            return None
        return pre

    for l in sorted(layers):
        handles.append(out_proj(blocks[l - 1]).register_forward_pre_hook(make(l)))
    try:
        yield store
    finally:
        for h in handles:
            h.remove()


def run_heads(tok, model, prompts, cids, n_heads, read=(), edit_fn=None, batch_size=16, device="cuda"):
    """Candidate logits [N, K] and {layer: [N, H*hd]} last-token pre-projection vectors."""
    import torch
    import model_utils as mu
    cand = torch.tensor(cids, device=device)
    logits_all, acts = [], {l: [] for l in read}
    with torch.no_grad():
        for i in range(0, len(prompts), batch_size):
            enc, pos = mu.encode(tok, prompts[i:i + batch_size], device)
            edit = edit_fn(i, min(i + batch_size, len(prompts))) if edit_fn else None
            with head_hooks(model, n_heads, read, edit) as store:
                lg = mu.last_logits(model, enc, pos)
            logits_all.append(lg.index_select(-1, cand).float().cpu())
            for l in read:
                acts[l].append(store[l])
    return torch.cat(logits_all), {l: torch.cat(v) for l, v in acts.items()}


def selftest():
    import torch
    from transformers import GPTNeoXConfig, GPTNeoXForCausalLM, LlamaConfig, LlamaForCausalLM
    torch.manual_seed(0)
    common = dict(vocab_size=64, hidden_size=32, num_hidden_layers=3, num_attention_heads=4, intermediate_size=64,
                  max_position_embeddings=64)
    for model in (GPTNeoXForCausalLM(GPTNeoXConfig(**common)),
                  LlamaForCausalLM(LlamaConfig(num_key_value_heads=4, **common))):
        model.eval()
        H = 4
        a = torch.randint(0, 64, (4, 12))
        b = torch.randint(0, 64, (4, 12))
        b[:, -1] = a[:, -1]
        mask = torch.ones_like(a)
        layers = [1, 2, 3]

        def logits(ids, read=(), edit=None):
            with torch.no_grad(), head_hooks(model, H, read, edit) as st:
                lg = model(input_ids=ids, attention_mask=mask).logits[:, -1, :]
            return lg, st
        la, sa = logits(a, read=layers)
        lb, sb = logits(b, read=layers)
        assert not torch.allclose(la, lb, atol=1e-3)
        assert sa[1].shape[-1] == 32                                   # H * head_dim
        l_self, _ = logits(a, edit={l: (range(H), sa[l]) for l in layers})
        assert torch.allclose(l_self, la, atol=1e-4)                   # own values back: unchanged
        l_all, _ = logits(a, edit={l: (range(H), sb[l]) for l in layers})
        assert torch.allclose(l_all, lb, atol=1e-4), float((l_all - lb).abs().max())   # every head, every layer: b
        l_one, _ = logits(a, edit={1: ([2], sb[1])})
        assert not torch.allclose(l_one, la, atol=1e-6) and not torch.allclose(l_one, lb, atol=1e-4)
        l_none, _ = logits(a, edit={1: ([], sb[1])})
        assert torch.allclose(l_none, la, atol=1e-5)                   # no heads: unchanged
    print("head_patch selftest ok (GPT-NeoX and Llama: own values, all heads, one head, no heads)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--revision", default=None)
    ap.add_argument("--tasks", nargs="+", default=["vartrack_d1", "vartrack_d3"])
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--layers", type=int, nargs="+", default=None, help="default: every 4th layer from the middle")
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--out", default="head_patch_results")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not args.model or (args.step is None) == (args.revision is None):
        raise SystemExit("give --model and exactly one of --step or --revision")
    revision = args.revision or f"step{args.step}"

    import torch
    import model_utils as mu
    from perturb import swap_chains
    from tasks import build_all

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = (torch.float16 if "pythia" in args.model else torch.bfloat16) if dev == "cuda" else torch.float32
    tok, model = mu.load(args.model, revision, dev, dtype)
    L = mu.n_layers(model)
    H = int(model.config.num_attention_heads)
    layers = args.layers or sorted(set(range(L // 2, L + 1, 4)) | {L})
    items_all = build_all(args.n, args.seed, shots=2, layout="blocked")
    out = dict(model=args.model, revision=revision, n_layers=L, n_heads=H, layers=layers, tasks={})
    for t in args.tasks:
        items = items_all[t]
        orig = [it["prompt"] for it in items]
        swp = [swap_chains(p) for p in orig]
        cids = mu.candidate_ids(tok, items[0]["candidates"])
        lo, _ = run_heads(tok, model, orig, cids, H, batch_size=args.batch_size, device=dev)
        ls, src = run_heads(tok, model, swp, cids, H, read=layers, batch_size=args.batch_size, device=dev)
        po, ps = lo.argmax(-1).numpy(), ls.argmax(-1).numpy()
        keep = np.where(po != ps)[0]                                   # only questions where the two orders differ
        print(t, "questions where the two orders differ:", len(keep), "of", len(items), flush=True)
        res = dict(n=len(items), n_differ=int(len(keep)), layers={})
        if len(keep) == 0:
            out["tasks"][t] = res
            continue
        sub_o = [orig[i] for i in keep]
        sub_ps = ps[keep]
        sub_src = {l: src[l][keep] for l in layers}

        def transfer(l, heads):
            lg, _ = run_heads(tok, model, sub_o, cids, H, edit_fn=lambda i0, i1: {l: (heads, sub_src[l][i0:i1])},
                              batch_size=args.batch_size, device=dev)
            return float((lg.argmax(-1).numpy() == sub_ps).mean())
        for l in layers:
            per_head = [transfer(l, [h]) for h in range(H)]
            top = [int(h) for h in np.argsort(per_head)[::-1][:5]]
            res["layers"][l] = dict(per_head=per_head, top5=top, top5_together=transfer(l, top),
                                    all_heads=transfer(l, list(range(H))))
            print(t, f"layer {l:>2}: best head {top[0]} ({per_head[top[0]]:.3f}), "
                  f"top5 together {res['layers'][l]['top5_together']:.3f}, all heads {res['layers'][l]['all_heads']:.3f}",
                  flush=True)
        out["tasks"][t] = res
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, f"{args.model.split('/')[-1]}__{revision}.json"), "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
