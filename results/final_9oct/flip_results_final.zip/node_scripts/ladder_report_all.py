"""The checkpoint ladder with the early steps added (exploratory; the registered C30 report ladder_report.py is untouched).

Merges several steer / probe folders and shows steps 0, 256, 512, 1000, 2000 next to the registered 4000...143000, so the
onset of 'readable' and 'used' can be seen. Steps with no data show '-'.

  python3 ladder_report_all.py \
    --steer $PERSIST/fullday/ladder $PERSIST/fullday/ladder_early \
    --probe $PERSIST/fullday/ladder_probe $PERSIST/fullday/ladder_probe_early $PERSIST/fullday/ladder_probe_step0
"""
import argparse

import ladder_report as lr

ap = argparse.ArgumentParser()
ap.add_argument("--steer", nargs="+", required=True)
ap.add_argument("--probe", nargs="+", required=True)
a = ap.parse_args()
steer, probe = {}, {}
for d in a.steer:
    steer.update(lr.load_steer(d))
for d in a.probe:
    probe.update(lr.load_probe(d))
lr.STEPS = (0, 256, 512, 1000, 2000) + tuple(lr.STEPS)
lr.show(steer, probe)
