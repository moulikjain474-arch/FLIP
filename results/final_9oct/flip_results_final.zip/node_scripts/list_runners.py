"""Index of every run_*.sh / smoke*.sh: its first comment lines, for the data book (added 9 Oct).

  python3 list_runners.py --root . > RUNNERS.md
Read-only. Prints a markdown table: runner | what it ran (first comment line). Edit the 'claims' column by hand if you want it.
"""
import argparse
import glob
import os

ap = argparse.ArgumentParser()
ap.add_argument("--root", default=".")
a = ap.parse_args()
print("| runner | what it ran | produced under |")
print("|---|---|---|")
for f in sorted(glob.glob(os.path.join(a.root, "**", "run_*.sh"), recursive=True) + glob.glob(os.path.join(a.root, "**", "smoke*.sh"), recursive=True)):
    desc, outs = "", set()
    for line in open(f, errors="ignore"):
        s = line.strip()
        if s.startswith("#") and not s.startswith("#!") and not desc and len(s) > 3:
            desc = s.lstrip("# ").strip()
        for tok in s.replace("$OUT/", " $OUT/").split():
            if tok.startswith("$OUT/") or "fullday/" in tok:
                outs.add(tok.strip('"').split("/")[1] if tok.startswith("$OUT/") else tok.split("fullday/")[1].split("/")[0])
    outs = sorted(o.strip(".,;:)(\"'$") for o in outs if o.strip(".,;:)(\"'$") and "$" not in o.strip(".,;:)(\"'")[:1])
    print(f"| `{os.path.basename(f)}` | {desc.replace('|', '/')} | {', '.join(outs[:6])} |")
