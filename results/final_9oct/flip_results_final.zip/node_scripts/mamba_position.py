"""Does a state-space model (no attention) also show the order effect? Behavioral only, standalone.

Same items, same scoring as position_test.py (it imports its analyse()), but runs one prompt at a time with no padding and
no position ids, because HF Mamba takes neither. Output file names match position_test.py so stability_table.py reads them.

  python3 mamba_position.py --model state-spaces/mamba-1.4b-hf --layout blocked --out $PERSIST/fullday/position_mamba/mamba-1.4b-hf
"""
import argparse
import json
import os

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

import model_utils as mu
from position_test import analyse
from steer_stage import distractor_index
from tasks import build_all


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", required=True)
    ap.add_argument("--tasks", nargs="+", default=["vartrack_d1", "vartrack_d2", "vartrack_d3"])
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--shots", type=int, default=2)
    ap.add_argument("--layout", choices=("interleaved", "blocked"), default="blocked")
    ap.add_argument("--out", default="position_results")
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tok = AutoTokenizer.from_pretrained(a.model)
    model = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=torch.float32 if dev == "cpu" else torch.bfloat16).to(dev).eval()
    all_items = build_all(a.n, a.seed, shots=a.shots, layout=a.layout)
    summary = dict(model=a.model, revision="main", layout=a.layout, tasks={})
    for task in a.tasks:
        items = all_items[task]
        cids = torch.tensor(mu.candidate_ids(tok, items[0]["candidates"]), device=dev)
        pred = []
        with torch.no_grad():
            for it in items:
                ids = tok(it["prompt"], return_tensors="pt", add_special_tokens=False)["input_ids"].to(dev)
                logits = model(input_ids=ids).logits[0, -1]
                pred.append(int(logits.index_select(-1, cids).argmax()))
        res = analyse(items, np.array(pred), None)
        summary["tasks"][task] = res
        pl = res["picks_later"]
        print(f"{task}: correct later={res['query_chain_later']['correct']} earlier={res['query_chain_earlier']['correct']} "
              f"picks_later={pl['rate']} CI={pl['ci95']}", flush=True)
    os.makedirs(a.out, exist_ok=True)
    name = f"{a.model.replace('/', '__')}__main__{a.layout}.json"
    json.dump(summary, open(os.path.join(a.out, name), "w"), indent=2)
    print("wrote", os.path.join(a.out, name))


if __name__ == "__main__":
    main()
