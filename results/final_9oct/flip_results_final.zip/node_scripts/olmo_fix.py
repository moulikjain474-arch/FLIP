"""Run position_test.py or perturb_test.py for an OLMo checkpoint whose own tokenizer files are broken.

OLMo-2's checkpoint branch stage1-step186000 has no usable tokenizer (loading it crashes inside transformers), but the
tokenizer is the same for every checkpoint, so this loads the tokenizer from `main` and the WEIGHTS from the requested revision.

  python3 olmo_fix.py position_test.py --model allenai/OLMo-2-1124-7B --revision stage1-step186000-tokens781B --out DIR
"""
import runpy
import sys

from transformers import AutoTokenizer

_orig = AutoTokenizer.from_pretrained


def _from_pretrained(cls, name, *a, **k):
    k.pop("revision", None)
    return _orig(name, *a, **k)


AutoTokenizer.from_pretrained = classmethod(_from_pretrained)
script = sys.argv[1]
sys.argv = [script] + sys.argv[2:]
runpy.run_path(script, run_name="__main__")
