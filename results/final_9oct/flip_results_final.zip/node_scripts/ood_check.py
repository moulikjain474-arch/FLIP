"""Are the planted states still inside the range of natural states? (audit A8, exploratory, added 9 Oct after results were seen)

Concern (Grant & Tartaglini 2025, Control and Predictivity in Neural Interpretability): an intervention can work simply because it
pushes the activation somewhere the model never goes. plant_normmatch.py already shows the effect needs the class-mean direction,
not just a push of that size. This script asks the other half: how unusual is the planted state compared with natural ones?

For the held-out questions at one layer it builds the last-token state under four conditions: natural, learned plant, and the two
norm-matched random pushes (rand_full, rand_in_sub), exactly as plant_normmatch.py. A reference is fitted on the TRAIN
questions' natural states (top-k principal components). For every state it reports
  in_pc   distance inside the top-k components (each scaled by its natural spread)       -> "unusual along natural directions"
  resid   size of what is left outside those components, relative to the natural median  -> "pushed off the natural manifold"
  norm    the state's length, relative to the natural median
  share_beyond95   share of questions whose value exceeds the 95th percentile of the natural HELD-OUT values (natural is ~5% by definition)
Read it as: if the learned plant sits near the natural range on in_pc and resid while rand_full does not, the plant is not working
because it is out of distribution. If the plant is also far out, say so as a limitation. Nothing here is a registered claim.

  python3 ood_check.py --model EleutherAI/pythia-6.9b --step 143000 --task vartrack_d1 --layer 22 --out fullday/ood_check
  python3 ood_check.py --selftest
"""
import argparse
import json
import os

import numpy as np


def fit_reference(Htr, k=32):
    import torch
    mean = Htr.mean(0)
    X = Htr - mean
    k = int(min(k, X.shape[0] - 1, X.shape[1]))
    U, S, Vt = torch.linalg.svd(X, full_matrices=False)
    V = Vt[:k].T                                          # [d, k]
    var = (S[:k] ** 2) / max(X.shape[0] - 1, 1)
    return dict(mean=mean, V=V, var=var.clamp_min(1e-12))


def metrics(ref, H):
    import torch
    X = H - ref["mean"]
    Z = X @ ref["V"]
    in_pc = ((Z ** 2 / ref["var"]).sum(-1) / Z.shape[1]).sqrt()
    resid = (X - Z @ ref["V"].T).norm(dim=-1)
    return dict(in_pc=in_pc.numpy(), resid=resid.numpy(), norm=H.norm(dim=-1).numpy())


def report(ref, natural_test, variants):
    nat = metrics(ref, natural_test)
    med = {m: float(np.median(v)) for m, v in nat.items()}
    thr = {m: float(np.percentile(v, 95)) for m, v in nat.items()}
    out = {}
    for name, H in [("natural", natural_test)] + list(variants.items()):
        m = metrics(ref, H)
        out[name] = {k: dict(median_rel=float(np.median(v) / med[k]), share_beyond95=float((v > thr[k]).mean()))
                     for k, v in m.items()}
    return out


def selftest():
    import torch
    torch.manual_seed(0)
    d, n = 64, 400
    A = torch.randn(d, d) * (torch.linspace(2.0, 0.1, d))          # anisotropic natural states
    Htr, Hte = torch.randn(n, d) @ A, torch.randn(n, d) @ A
    ref = fit_reference(Htr, k=16)
    near = Hte + 0.05 * torch.randn(n, d)                             # tiny edit: should look natural
    push = torch.randn(n, d)
    far = Hte + 8.0 * Hte.norm(dim=-1, keepdim=True) / 6.0 * push / push.norm(dim=-1, keepdim=True)   # big random push
    rep = report(ref, Hte, {"near": near, "far": far})
    assert rep["natural"]["in_pc"]["share_beyond95"] < 0.10
    assert rep["near"]["resid"]["share_beyond95"] < 0.20, rep["near"]
    assert rep["far"]["resid"]["share_beyond95"] > 0.9 and rep["far"]["norm"]["share_beyond95"] > 0.9, rep["far"]
    print("ood_check selftest ok (small edit looks natural; large random push is flagged)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--revision", default=None)
    ap.add_argument("--task", default="vartrack_d1")
    ap.add_argument("--layer", type=int, default=None)
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n-rand", type=int, default=5)
    ap.add_argument("--k", type=int, default=32)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--out", default="ood_check_results")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not args.model or (args.step is None) == (args.revision is None):
        raise SystemExit("give --model and exactly one of --step or --revision")
    revision = args.revision or f"step{args.step}"

    import torch
    import model_utils as mu
    from plant_normmatch import norm_matched, unit_in_subspace
    from steer import split
    from steer_stage import class_geometry, distractor_index
    from tasks import build_all

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    items = build_all(args.n, args.seed, shots=2, layout="blocked")[args.task]
    rng = np.random.default_rng(args.seed + 1)                 # same planted values and split as steer_stage.py / plant_normmatch.py
    for it in items:
        it["_dis"] = distractor_index(it, None)
        others = [c for c in range(len(it["candidates"])) if c not in (it["label"], it["_dis"])]
        it["_plant"] = int(rng.choice(others))
    items = [it for it in items if it["_dis"] != it["label"]]
    train, test = split(items, args.seed)

    dtype = torch.float16 if dev == "cuda" else torch.float32
    tok, model = mu.load(args.model, revision, dev, dtype)
    L = mu.n_layers(model)
    layer = L // 2 if args.layer is None else args.layer
    cids = mu.candidate_ids(tok, items[0]["candidates"])
    K = len(cids)
    _, acts = mu.run(tok, model, [it["prompt"] for it in train], cids, read_layers=[layer], batch_size=args.batch_size, device=dev)
    H = acts[layer].float().cpu()
    _, acts_t = mu.run(tok, model, [it["prompt"] for it in test], cids, read_layers=[layer], batch_size=args.batch_size, device=dev)
    Ht = acts_t[layer].float().cpu()
    mean = H.mean(0)
    cm_dis, Q_dis = class_geometry(H, torch.tensor([it["_dis"] for it in train]), K)
    cm_dis, Q_dis = cm_dis.float().cpu(), Q_dis.float().cpu()
    targets = torch.tensor([it["_plant"] for it in test])

    def plant(h, _l):
        tgt = cm_dis[targets] - mean
        return h - ((h - mean) @ Q_dis) @ Q_dis.T + (tgt @ Q_dis) @ Q_dis.T

    ref = fit_reference(H, k=args.k)
    g = torch.Generator().manual_seed(args.seed + 7)
    variants = {"plant_dis": plant(Ht, layer)}
    per_draw = {"rand_full": [], "rand_in_sub": []}
    for _ in range(args.n_rand):
        U = torch.randn(H.shape[1], generator=g)
        per_draw["rand_full"].append(norm_matched(plant, U / U.norm())(Ht, layer))
        per_draw["rand_in_sub"].append(norm_matched(plant, unit_in_subspace(Q_dis, g))(Ht, layer))
    for fam, lst in per_draw.items():
        for i, Hv in enumerate(lst):
            variants[f"{fam}{i}"] = Hv
    rep = report(ref, Ht, variants)
    shift = ((variants["plant_dis"] - Ht).norm(dim=-1) / Ht.norm(dim=-1)).median().item()
    summ = dict(model=args.model, revision=revision, task=args.task, layer=layer, n_train=len(train), n_test=len(test), k=ref["V"].shape[1],
                plant_shift_rel_norm=shift, conditions=rep)
    print(f"{'condition':14s} {'in_pc rel':>10s} {'beyond95':>9s} {'resid rel':>10s} {'beyond95':>9s} {'norm rel':>9s} {'beyond95':>9s}")
    show = ["natural", "plant_dis"] + [f"{f}{i}" for f in per_draw for i in range(args.n_rand)]
    for name in show:
        r = rep[name]
        print(f"{name:14s} {r['in_pc']['median_rel']:10.2f} {r['in_pc']['share_beyond95']:9.2f} {r['resid']['median_rel']:10.2f} "
              f"{r['resid']['share_beyond95']:9.2f} {r['norm']['median_rel']:9.2f} {r['norm']['share_beyond95']:9.2f}")
    print(f"planted edit size: median {shift:.2f} of the state's length")
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, f"{args.model.split('/')[-1]}__{revision}__{args.task}__L{layer}.json"), "w") as f:
        json.dump(summ, f, indent=2)


if __name__ == "__main__":
    main()
