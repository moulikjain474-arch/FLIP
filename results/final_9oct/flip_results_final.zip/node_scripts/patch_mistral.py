import sys
p = "model_utils.py"
s = open(p).read()
if "FLIP_BOS" in s:
    print("already patched"); sys.exit(0)
old1 = '''        t = tok(c, add_special_tokens=False)["input_ids"]
        if len(t) != 1:'''
new1 = '''        t = tok(c, add_special_tokens=False)["input_ids"]
        if len(t) == 2 and tok.convert_ids_to_tokens(t[0]) in ("\\u2581", " "):
            t = t[1:]  # sentencepiece lone-space prefix (Mistral/Llama): keep the digit piece
        if len(t) != 1:'''
old2 = '''    enc = tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False).to(device)'''
new2 = '''    import os
    if os.environ.get("FLIP_BOS") == "1" and tok.bos_token:
        prompts = [tok.bos_token + p for p in prompts]
    enc = tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False).to(device)'''
assert old1 in s and old2 in s, "anchor not found"
open(p, "w").write(s.replace(old1, new1).replace(old2, new2))
print("patched ok")
