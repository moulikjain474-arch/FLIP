"""Compact printout of the three patching results (whole-state A5, sublayer A4, per-head A6).

  python3 patch_summary.py --root /scratch/flip_out/fullday
Reads root/patch, root/component_patch, root/head_patch (one JSON each). Read-only.
"""
import argparse
import glob
import json
import os


def load(d):
    out = []
    for f in sorted(glob.glob(os.path.join(d, "*.json"))):
        out.append((os.path.basename(f), json.load(open(f))))
    return out


def f3(x):
    return "  -  " if x is None else f"{x:5.3f}"


def lnum(d):
    return sorted(d, key=int)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    a = ap.parse_args()
    for name, js in load(os.path.join(a.root, "patch")):
        print(f"\n== A5 whole-state patching: {name}")
        for t, r in js["tasks"].items():
            print(f"{t}: {r['n_differ']} of {r['n']} questions change with order; acc original {r['acc_orig']:.3f}, swapped {r['acc_swap']:.3f}")
            print("  layer  transfer(two chains)  transfer(single-chain control)")
            ctrl = r.get("control", {}).get("layers", {})
            for l in lnum(r["layers"]):
                print(f"  {int(l):>4}   {f3(r['layers'][l]['transfer'])}                {f3(ctrl.get(l, {}).get('transfer'))}")
    for name, js in load(os.path.join(a.root, "component_patch")):
        print(f"\n== A4 attention vs MLP: {name}")
        for t, r in js["tasks"].items():
            print(f"{t}: {r['n_differ']} of {r['n']} change with order")
            print("  layer   attn transfer   mlp transfer")
            for l in lnum(r["layers"]):
                print(f"  {int(l):>4}      {f3(r['layers'][l]['attn']['transfer'])}          {f3(r['layers'][l]['mlp']['transfer'])}")
    for name, js in load(os.path.join(a.root, "head_patch")):
        print(f"\n== A6 per-head patching: {name} ({js['n_heads']} heads per layer)")
        for t, r in js["tasks"].items():
            print(f"{t}: {r['n_differ']} of {r['n']} change with order")
            print("  layer  best head (transfer)   top5 together   all heads")
            for l in lnum(r["layers"]):
                x = r["layers"][l]
                b = x["top5"][0]
                print(f"  {int(l):>4}   head {b:>2} ({f3(x['per_head'][b])})        {f3(x['top5_together'])}         {f3(x['all_heads'])}")


if __name__ == "__main__":
    main()
