"""Is the random control for the plant test too easy? A norm-matched control (audit A7, exploratory).

steer_stage.py plants by overwriting a subspace's coordinates with a class mean's coordinates. For a RANDOM subspace that edit
is tiny almost by construction (a random subspace barely contains the class-mean offset), so "random does nothing" could simply
mean "random changes nothing because it barely edits". A fair control gives the control the SAME size of push. Here, for every
test question, the learned plant edit's displacement has some norm; two controls push the last-token state by exactly that norm,
in a different direction:
  rand_full   a fixed random direction in the whole space             (a push of the same size, anywhere)
  rand_in_sub a fixed random direction INSIDE the learned subspace    (right place, wrong direction)
If the learned plant still makes the model answer the planted number far more often than both, the effect needs the
class-mean direction, not just a large push. Accuracy is reported too, to show whether a big push merely breaks the model.
Same items, split, planted values, layer and single-layer scope as steer_stage.py.

  python3 plant_normmatch.py --model EleutherAI/pythia-6.9b --step 143000 --task vartrack_d1 --layer 22
  python3 plant_normmatch.py --selftest
"""
import argparse
import json
import os

import numpy as np


def norm_matched(learned_fn, U):
    """Edit fn(h, layer): h + ||learned_fn(h) - h|| * U   (U is a unit vector [d]); same push size, different direction."""
    def fn(h, layer):
        n = (learned_fn(h, layer) - h).norm(dim=-1, keepdim=True)
        return h + n * U.to(h.device, h.dtype)
    return fn


def unit_in_subspace(Q, gen):
    import torch
    z = torch.randn(Q.shape[1], generator=gen)
    v = Q @ z
    return v / v.norm()


def selftest():
    import torch
    torch.manual_seed(0)
    d, r = 16, 3
    Q = torch.linalg.qr(torch.randn(d, r))[0]
    cm = torch.randn(10, d)
    mean = torch.randn(d)
    h = torch.randn(5, d)
    tgt = (cm[torch.tensor([1, 2, 3, 4, 5])] - mean)

    def learned(hh, _l):
        return hh - ((hh - mean) @ Q) @ Q.T + (tgt @ Q) @ Q.T
    g = torch.Generator().manual_seed(1)
    U_full = torch.randn(d, generator=g)
    U_full = U_full / U_full.norm()
    U_sub = unit_in_subspace(Q, g)
    for U in (U_full, U_sub):
        out = norm_matched(learned, U)(h, 0)
        assert torch.allclose((out - h).norm(dim=-1), (learned(h, 0) - h).norm(dim=-1), atol=1e-5)
    resid = U_sub - Q @ (Q.T @ U_sub)
    assert resid.norm() < 1e-5 and abs(float(U_sub.norm()) - 1) < 1e-5
    print("plant_normmatch selftest ok (same push norm; in-subspace direction stays in the subspace)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--revision", default=None)
    ap.add_argument("--task", default="vartrack_d1")
    ap.add_argument("--layer", type=int, default=None)
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n-rand", type=int, default=5)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--out", default="plant_normmatch_results")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not args.model or (args.step is None) == (args.revision is None):
        raise SystemExit("give --model and exactly one of --step or --revision")
    revision = args.revision or f"step{args.step}"

    import torch
    import model_utils as mu
    from steer import split
    from steer_stage import class_geometry, distractor_index, evaluate, paired
    from tasks import build_all

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    items = build_all(args.n, args.seed, shots=2, layout="blocked")[args.task]
    rng = np.random.default_rng(args.seed + 1)             # identical to steer_stage.py: same planted values, same split
    for it in items:
        it["_dis"] = distractor_index(it, None)
        others = [c for c in range(len(it["candidates"])) if c not in (it["label"], it["_dis"])]
        it["_plant"] = int(rng.choice(others))
    items = [it for it in items if it["_dis"] != it["label"]]
    train, test = split(items, args.seed)

    dtype = torch.float16 if dev == "cuda" else torch.float32
    tok, model = mu.load(args.model, revision, dev, dtype)
    L = mu.n_layers(model)
    layer = L // 2 if args.layer is None else args.layer
    cids = mu.candidate_ids(tok, items[0]["candidates"])
    K = len(cids)
    _, acts = mu.run(tok, model, [it["prompt"] for it in train], cids, read_layers=[layer],
                     batch_size=args.batch_size, device=dev)
    H = acts[layer]
    mean = H.mean(0)
    cm_dis, Q_dis = class_geometry(H, torch.tensor([it["_dis"] for it in train]), K)

    def make_plant(idx):
        targets = torch.tensor([test[j]["_plant"] for j in idx])

        def fn(h, _l):
            B = Q_dis.to(h.device, h.dtype)
            m = mean.to(h.device, h.dtype)
            tgt = (cm_dis[targets] - mean).to(h.device, h.dtype)
            return h - ((h - m) @ B) @ B.T + (tgt @ B) @ B.T
        return fn

    g = torch.Generator().manual_seed(args.seed + 7)
    conditions = {"natural": None, "plant_dis": make_plant}
    for k in range(args.n_rand):
        U = torch.randn(H.shape[1], generator=g)
        U_full = U / U.norm()
        U_sub = unit_in_subspace(Q_dis, g)
        conditions[f"rand_full{k}"] = (lambda idx, U=U_full: norm_matched(make_plant(idx), U))
        conditions[f"rand_in_sub{k}"] = (lambda idx, U=U_sub: norm_matched(make_plant(idx), U))

    labels = np.array([it["label"] for it in test])
    plant_idx = np.array([it["_plant"] for it in test])
    res = {}
    for name, make in conditions.items():
        _, pred = evaluate(tok, model, test, cids, {layer}, make, args.batch_size, dev)
        res[name] = dict(planted=(pred == plant_idx).astype(float), correct=(pred == labels).astype(float))
        print(f"{name:14s} planted={res[name]['planted'].mean():.3f}  correct={res[name]['correct'].mean():.3f}", flush=True)
    summ = dict(model=args.model, revision=revision, task=args.task, layer=layer, n_test=len(test), rank=int(Q_dis.shape[1]),
                rates={n: {m: float(v.mean()) for m, v in r.items()} for n, r in res.items()})
    for fam in ("rand_full", "rand_in_sub"):
        names = [f"{fam}{k}" for k in range(args.n_rand)]
        mean_rate = np.mean([res[n]["planted"] for n in names], axis=0)
        summ[fam] = dict(planted_rate=float(mean_rate.mean()),
                         largest_draw=max(float(res[n]["planted"].mean()) for n in names),
                         correct_rate=float(np.mean([res[n]["correct"].mean() for n in names])),
                         plant_minus=paired(res["plant_dis"]["planted"], mean_rate))
        print(fam, "mean planted", round(summ[fam]["planted_rate"], 3), "largest draw", round(summ[fam]["largest_draw"], 3),
              "| plant_dis", round(float(res["plant_dis"]["planted"].mean()), 3), flush=True)
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, f"{args.model.split('/')[-1]}__{revision}__{args.task}__L{layer}.json"), "w") as f:
        json.dump(summ, f, indent=2)


if __name__ == "__main__":
    main()
