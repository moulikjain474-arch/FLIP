#!/usr/bin/env bash
# Waits for run_final12h.sh to finish, then runs the additions in order of cost (cheapest first):
#   1 position padding (audit A3), 2 digit breakdown (audit A2), 3 sublayer patching (A4), 3b per-head patching (A6), 4 whole-state patching (A5), 5 the checkpoint ladder (C30, rank sweep; 6.9B then 1.4B).
# Start it once, at any time:
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_after.sh > $PERSIST/log_after.txt 2>&1 < /dev/null &)
# Progress:  grep -E "^=== |FAILED" $PERSIST/log_after.txt | tail -20
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
mkdir -p $OUT
while pgrep -f "[r]un_final12h.sh" >/dev/null; do sleep 30; done
echo "=== AFTER: main run finished $(date)"

echo "=== A3 position padding $(date)"
python3 head_pad_test.py --model EleutherAI/pythia-12b --step 143000 --out $OUT/headpad || echo "FAILED headpad pythia-12b"
rm -rf $HF_HOME/hub/models--EleutherAI--pythia-12b

echo "=== A2 digit breakdown $(date)"
for m in Qwen/Qwen2.5-7B-Instruct allenai/OLMo-2-1124-7B-Instruct; do
  for th in med coins; do
    python3 digit_breakdown.py --model $m --revision main --theme $th --depths 3 --out $OUT/digits || echo "FAILED digits $m $th"
  done
  rm -rf $HF_HOME/hub/models--${m//\//--}
done
python3 digit_breakdown.py --model EleutherAI/pythia-6.9b --step 143000 --theme coins --depths 1 3 --out $OUT/digits || echo "FAILED digits pythia-6.9b"
rm -rf $HF_HOME/hub/models--EleutherAI--pythia-6.9b

echo "=== A4 sublayer patching $(date)"
python3 component_patch.py --selftest || echo "FAILED component_patch selftest"
python3 component_patch.py --model EleutherAI/pythia-6.9b --step 143000 --every 4 --out $OUT/component_patch || echo "FAILED component_patch"

echo "=== A6 per-head patching $(date)"
python3 head_patch.py --selftest || echo "FAILED head_patch selftest"
python3 head_patch.py --model EleutherAI/pythia-6.9b --step 143000 --out $OUT/head_patch || echo "FAILED head_patch"

echo "=== A5 whole-state patching, with single-chain control $(date)"
python3 patch_test.py --model EleutherAI/pythia-6.9b --step 143000 --every 4 --out $OUT/patch || echo "FAILED patch_test"

echo "=== C30 ladder $(date)"
bash run_ladder.sh
echo "=== AFTER ALL DONE $(date)"
