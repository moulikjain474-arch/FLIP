#!/usr/bin/env bash
# Early checkpoints for the ladder (the chain-label probe was already at 1.000 by step 4000, so onset must be earlier).
# Kept in separate folders so the registered six-checkpoint C30 scoring is not changed.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_early.sh > $PERSIST/log_early.txt 2>&1 < /dev/null &)
# Score:  python3 ladder_report.py --steer $PERSIST/fullday/ladder_early --probe $PERSIST/fullday/ladder_probe_early
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
M=EleutherAI/pythia-6.9b
for s in 2000 1000 512 256; do
  echo "=== EARLY step $s $(date)"
  for t in vartrack_d1 vartrack_d3; do
    python3 steer_stage.py --model $M --step $s --task $t --layer 22 --scope single \
      --n-rand 5 --plant-rand --out $OUT/ladder_early || echo "FAILED early steer $s $t"
  done
  python3 chain_probe.py --model $M --step $s --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 \
    --out $OUT/ladder_probe_early || echo "FAILED early probe $s"
done
echo "=== EARLY ALL DONE $(date)"
