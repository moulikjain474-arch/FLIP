#!/usr/bin/env bash
# Second queue, started after run_after.sh finished (node was otherwise idle). Cheapest first; every item is independent.
#   1 where the order-choice site forms: sublayer, per-head and whole-state patching on Pythia-6.9B at earlier checkpoints
#   2 padding test (absolute position vs distance) on 6.9B and 1.4B
#   3 the 6.9B checkpoint ladder again with a different question sample (seed 1), to see if C30 is stable
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_extra2.sh > $PERSIST/log_extra2.txt 2>&1 < /dev/null &)
# Progress:  grep -E "^=== |FAILED" $PERSIST/log_extra2.txt | tail -20
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
mkdir -p $OUT
M=EleutherAI/pythia-6.9b
echo "=== X1 patching at earlier checkpoints $(date)"
for s in 16000 64000; do
  echo "=== X1 step $s $(date)"
  python3 component_patch.py --model $M --step $s --every 4 --out $OUT/component_patch_s$s || echo "FAILED component_patch $s"
  python3 head_patch.py --model $M --step $s --out $OUT/head_patch_s$s || echo "FAILED head_patch $s"
  python3 patch_test.py --model $M --step $s --every 4 --out $OUT/patch_s$s || echo "FAILED patch_test $s"
done

echo "=== X2 padding test $(date)"
python3 head_pad_test.py --model $M --step 143000 --out $OUT/headpad_6p9b || echo "FAILED headpad 6.9b"
python3 head_pad_test.py --model EleutherAI/pythia-1.4b --step 143000 --out $OUT/headpad_1p4b || echo "FAILED headpad 1.4b"

echo "=== X3 ladder, second question sample (seed 1) $(date)"
for s in 4000 16000 64000 8000 32000 143000; do
  echo "=== X3 step $s $(date)"
  for t in vartrack_d1 vartrack_d3; do
    python3 steer_stage.py --model $M --step $s --task $t --layer 22 --scope single --seed 1 \
      --n-rand 5 --plant-rand --rank-sweep --save-items --out $OUT/ladder_s1 || echo "FAILED ladder_s1 steer $s $t"
  done
  python3 chain_probe.py --model $M --step $s --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 --seed 1 \
    --out $OUT/ladder_probe_s1 || echo "FAILED ladder_s1 probe $s"
done
echo "=== EXTRA2 ALL DONE $(date)"
