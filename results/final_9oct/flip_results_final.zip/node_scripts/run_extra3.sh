#!/usr/bin/env bash
# Remaining items: (1) per-seed steering on the nine 410M seeds, (2) norm-matched control on d3 and at a second layer,
# (3) a Mamba (no-attention) behavioral test. Small jobs; they share the GPU with the other queues.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_extra3.sh > $PERSIST/log_extra3.txt 2>&1 < /dev/null &)
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
echo "=== Y1 per-seed steering (410M, layer 12) $(date)"
for m in pythia-410m pythia-410m-seed1 pythia-410m-seed2 pythia-410m-seed3 pythia-410m-seed5 pythia-410m-seed6 pythia-410m-seed7 pythia-410m-seed8 pythia-410m-seed9; do
  for t in vartrack_d1 vartrack_d3; do
    echo "=== Y1 $m $t $(date)"
    python3 steer_stage.py --model EleutherAI/$m --step 143000 --task $t --layer 12 --scope single --n-rand 5 --plant-rand --out $OUT/seed_steer/$m || echo "FAILED Y1 $m $t"
  done
done
echo "=== Y2 norm-matched $(date)"
python3 plant_normmatch.py --model EleutherAI/pythia-6.9b --step 143000 --task vartrack_d3 --layer 22 --out $OUT/plant_normmatch || echo "FAILED Y2 d3"
python3 plant_normmatch.py --model EleutherAI/pythia-6.9b --step 143000 --task vartrack_d1 --layer 16 --out $OUT/plant_normmatch || echo "FAILED Y2 L16"
echo "=== Y3 mamba $(date)"
for lay in blocked interleaved; do
  python3 mamba_position.py --model state-spaces/mamba-1.4b-hf --layout $lay --out $OUT/position_mamba/mamba-1.4b-hf || echo "FAILED Y3 mamba $lay"
done
echo "=== EXTRA3 ALL DONE $(date)"
