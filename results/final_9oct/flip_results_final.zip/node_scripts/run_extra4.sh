#!/usr/bin/env bash
# (1) Complete the layout matrix: position_test in BOTH layouts for every family, so the cross-family table compares like with like.
# (2) Fresh-question replication (claim C23): perturb_test with --seed 1 on 6.9B and 12B.
# Waits for run_extra3.sh to finish first (shared GPU).
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_extra4.sh > $PERSIST/log_extra4.txt 2>&1 < /dev/null &)
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
while pgrep -f "run_extra3.sh" > /dev/null; do sleep 60; done
echo "=== Z1 layout matrix $(date)"
for lay in blocked interleaved; do
  for m in pythia-410m pythia-1.4b pythia-6.9b pythia-12b; do
    echo "=== Z1 $m $lay $(date)"
    python3 position_test.py --model EleutherAI/$m --step 143000 --layout $lay --out $OUT/position_matrix/$m || echo "FAILED Z1 $m $lay"
    rm -rf $HF_HOME/hub/models--EleutherAI--$m
  done
  echo "=== Z1 OLMo $lay $(date)"
  python3 position_test.py --model allenai/OLMo-2-1124-7B --revision main --layout $lay --out $OUT/position_matrix/OLMo-2-1124-7B || echo "FAILED Z1 OLMo $lay"
  rm -rf $HF_HOME/hub/models--allenai--OLMo-2-1124-7B
done
echo "=== Z2 fresh questions (seed 1) $(date)"
for m in pythia-6.9b pythia-12b; do
  python3 perturb_test.py --model EleutherAI/$m --step 143000 --seed 1 --out $OUT/perturb_seed1 || echo "FAILED Z2 $m"
  rm -rf $HF_HOME/hub/models--EleutherAI--$m
done
echo "=== EXTRA4 ALL DONE $(date)"
