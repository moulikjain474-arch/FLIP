#!/usr/bin/env bash
# Replicate the early onset (readable at step 2000, used from 4000) on a fresh question sample (seed 1).
# Steps 2000 and 1000: steering + chain probe. Step 512: chain probe only.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_extra5.sh > $PERSIST/log_extra5.txt 2>&1 < /dev/null &)
# Score:  F=$PERSIST/fullday; python3 ladder_report_all.py --steer $F/ladder_s1 $F/ladder_early_s1 --probe $F/ladder_probe_s1 $F/ladder_probe_early_s1
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
M=EleutherAI/pythia-6.9b
for s in 2000 1000; do
  echo "=== E5 step $s $(date)"
  for t in vartrack_d1 vartrack_d3; do
    python3 steer_stage.py --model $M --step $s --task $t --layer 22 --scope single --seed 1 \
      --n-rand 5 --plant-rand --out $OUT/ladder_early_s1 || echo "FAILED E5 steer $s $t"
  done
  python3 chain_probe.py --model $M --step $s --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 --seed 1 \
    --out $OUT/ladder_probe_early_s1 || echo "FAILED E5 probe $s"
done
echo "=== E5 step 512 probe $(date)"
python3 chain_probe.py --model $M --step 512 --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 --seed 1 \
  --out $OUT/ladder_probe_early_s1 || echo "FAILED E5 probe 512"
echo "=== EXTRA5 ALL DONE $(date)"
