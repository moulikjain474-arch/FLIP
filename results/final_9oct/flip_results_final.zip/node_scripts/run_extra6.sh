#!/usr/bin/env bash
# Onset of chain-identity readability across INDEPENDENT TRAINING RUNS (the nine Pythia-410M seeds),
# probe only (small, fast). Steps 2000, 1000, 4000. Then seed-1 6.9B probe at 256 and 0 if time allows.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_extra6.sh > $PERSIST/log_extra6.txt 2>&1 < /dev/null &)
# Score:  python3 seed_onset.py --dir $PERSIST/fullday/onset_410m_seeds
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
for s in 2000 1000 4000; do
  for m in pythia-410m pythia-410m-seed1 pythia-410m-seed2 pythia-410m-seed3 pythia-410m-seed5 pythia-410m-seed6 pythia-410m-seed7 pythia-410m-seed8 pythia-410m-seed9; do
    echo "=== X6 $m step $s $(date)"
    python3 chain_probe.py --model EleutherAI/$m --step $s --tasks vartrack_d1 vartrack_d3 --every 2 --batch-size 32 \
      --out $OUT/onset_410m_seeds/$m || echo "FAILED X6 $m $s"
  done
done
for s in 256 0; do
  echo "=== X6 6.9b seed1 step $s $(date)"
  python3 chain_probe.py --model EleutherAI/pythia-6.9b --step $s --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 --seed 1 \
    --out $OUT/ladder_probe_early_s1 || echo "FAILED X6 6.9b $s"
done
echo "=== EXTRA6 ALL DONE $(date)"
