#!/usr/bin/env bash
# Fresh-question replication (seed 1, as claim C23) of the order-swap vs rename test in OTHER families.
# C23 covered Pythia-6.9B and 12B only. Exploratory: not registered. Runs alongside run_extra6.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_extra7.sh > $PERSIST/log_extra7.txt 2>&1 < /dev/null &)
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
for spec in allenai/OLMo-2-1124-7B:16 Qwen/Qwen2.5-7B:16 allenai/OLMo-2-1124-13B:8 Qwen/Qwen2.5-14B:8 mistralai/Mistral-7B-v0.1:16; do
  m=${spec%%:*}; b=${spec##*:}
  echo "=== X7 $m seed 1 $(date)"
  python3 perturb_test.py --model $m --revision main --seed 1 --batch-size $b --out $OUT/perturb_seed1_families || echo "FAILED X7 $m"
done
echo "=== EXTRA7 ALL DONE $(date)"
