#!/usr/bin/env bash
# Checkpoint ladder (claim C30, EXPERIMENTS.md section 4m): Pythia-6.9B, layer 22, depths 1 and 3, six checkpoints.
# Per checkpoint: the plant/erase test with 5 random-subspace controls (steer_stage.py) and the chain-identity probe
# (chain_probe.py). Run AFTER run_final12h.sh (it needs the patched steer_stage.py that run_final12h.sh creates).
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   bash run_ladder.sh
# Score:  python3 ladder_report.py --steer $PERSIST/fullday/ladder --probe $PERSIST/fullday/ladder_probe
# Order is chosen so a truncated run still shows the early/middle/late shape; each checkpoint is independent.
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
mkdir -p $OUT
python3 -c "import sklearn" 2>/dev/null || pip3 install --break-system-packages scikit-learn >/dev/null 2>&1
python3 -c "import sklearn" || { echo "FAILED ladder: scikit-learn missing"; exit 1; }
python3 patch_steer_stage.py >/dev/null; python3 patch_plant_rand.py >/dev/null
# model, edited layer, output suffix. 6.9B is the registered C30 ladder; 1.4B (layer 14 of 24) is an exploratory replication.
# --rank-sweep also plants inside only the top-r directions (r = 1..rank) at every checkpoint: how many dimensions the
# effect needs, per training stage. Score it with plant_margin.py.
for spec in "EleutherAI/pythia-6.9b:22:" "EleutherAI/pythia-1.4b:14:_1p4b"; do
  M=${spec%%:*}; rest=${spec#*:}; LAYER=${rest%%:*}; SUF=${rest#*:}
  echo "=== LADDER $M layer $LAYER $(date)"
  for s in 4000 16000 64000 8000 32000 143000; do
    echo "=== LADDER $M step $s $(date)"
    for t in vartrack_d1 vartrack_d3; do
      python3 steer_stage.py --model $M --step $s --task $t --layer $LAYER --scope single \
        --n-rand 5 --plant-rand --rank-sweep --save-items --out $OUT/ladder$SUF || echo "FAILED ladder steer $M $s $t"
    done
    python3 chain_probe.py --model $M --step $s --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 \
      --out $OUT/ladder_probe$SUF || echo "FAILED ladder probe $M $s"
  done
  rm -rf $HF_HOME/hub/models--${M//\//--}
  python3 ladder_report.py --steer $OUT/ladder$SUF --probe $OUT/ladder_probe$SUF || true
  python3 plant_margin.py --dir $OUT/ladder$SUF || true
done
echo "=== LADDER DONE $(date)"
