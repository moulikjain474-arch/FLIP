#!/usr/bin/env bash
# C18 (registered, EXPERIMENTS.md): the position habit across OLMo-2-7B's own training checkpoints (a second model family).
# Not in run_final12h.sh. Same two tests as the Pythia sweeps: position_test (first-or-last share) and perturb_test (order-swap/rename).
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_olmo.sh > $PERSIST/log_olmo.txt 2>&1 < /dev/null &)
# Progress:  grep -E "^=== |FAILED" $PERSIST/log_olmo.txt | tail
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
for f in position_test.py perturb_test.py model_utils.py; do [ -f $f ] || { echo "FAILED olmo: $f missing"; exit 1; }; done
OM=allenai/OLMo-2-1124-7B
REVS=$(python3 -c "import model_utils as mu; print(' '.join(r for _, _, r in mu.nearest_revisions('$OM', [0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0])))")
echo "=== OLMO checkpoints: $REVS"
[ -z "$REVS" ] && { echo "FAILED olmo revisions: could not list OLMo-2-7B checkpoints"; exit 1; }
for r in $REVS; do
  echo "=== OLMO $r $(date)"
  python3 position_test.py --model $OM --revision $r --out $OUT/position_olmo/OLMo-2-1124-7B || echo "FAILED olmo position $r"
  python3 perturb_test.py --model $OM --revision $r --out $OUT/perturb_olmo_traj || echo "FAILED olmo perturb $r"
  rm -rf $HF_HOME/hub/models--allenai--OLMo-2-1124-7B
done
echo "=== OLMO ALL DONE $(date)"
