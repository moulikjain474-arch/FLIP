#!/usr/bin/env bash
# Re-run the one OLMo checkpoint that failed (step 186000): tokenizer from main, weights from that checkpoint.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_olmo_fix.sh > $PERSIST/log_olmo_fix.txt 2>&1 < /dev/null &)
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
OM=allenai/OLMo-2-1124-7B
R=stage1-step186000-tokens781B
echo "=== OLMO FIX $R $(date)"
python3 olmo_fix.py position_test.py --model $OM --revision $R --out $OUT/position_olmo/OLMo-2-1124-7B || echo "FAILED fix position"
python3 olmo_fix.py perturb_test.py --model $OM --revision $R --out $OUT/perturb_olmo_traj || echo "FAILED fix perturb"
rm -rf $HF_HOME/hub/models--allenai--OLMo-2-1124-7B
echo "=== OLMO FIX DONE $(date)"
