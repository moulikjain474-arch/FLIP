#!/usr/bin/env bash
# Random-initialisation baselines for the probes (an IOI-circuit paper found its probe already at 89% at random init).
# Pythia publishes step0 (random weights). If these probes score high at step0 too, "readable" is true before any training.
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_step0.sh > $PERSIST/log_step0.txt 2>&1 < /dev/null &)
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
M=EleutherAI/pythia-6.9b
echo "=== STEP0 chain probe $(date)"
python3 chain_probe.py --model $M --step 0 --tasks vartrack_d1 vartrack_d3 --every 4 --batch-size 16 --out $OUT/ladder_probe_step0 || echo "FAILED step0 chain probe"
echo "=== STEP0 value probe $(date)"
python3 value_probe.py --model $M --step 0 --out $OUT/value_probe_step0 || echo "FAILED step0 value probe"
echo "=== STEP0 ALL DONE $(date)"
