#!/usr/bin/env bash
# Value probe ladder (replaces the chain-label probe as the "readable" rung). Runs next to run_extra2.sh (6.9B fits twice).
#   export PERSIST=/scratch/flip_out HF_HOME=/scratch/hf_cache
#   (setsid nohup bash run_value_probe.sh > $PERSIST/log_value_probe.txt 2>&1 < /dev/null &)
# Score:  python3 value_probe.py --report $PERSIST/fullday/value_probe
cd "$(dirname "$0")"
OUT=${PERSIST:?set PERSIST first}/fullday
: ${HF_HOME:?set HF_HOME first}
for s in 512 1000 2000 4000 8000 16000 32000 64000 143000; do
  echo "=== VALUE PROBE step $s $(date)"
  python3 value_probe.py --model EleutherAI/pythia-6.9b --step $s --out $OUT/value_probe || echo "FAILED value_probe $s"
done
echo "=== VALUE PROBE ALL DONE $(date)"
