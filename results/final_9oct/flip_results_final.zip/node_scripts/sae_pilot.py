"""SAE PILOT (exploratory, ~10 minutes): does an off-the-shelf sparse autoencoder see the order flip?

Model: Gemma-2-2B with Google's public Gemma Scope residual SAE (nothing is trained). For every question we compare the
last-token SAE code under the original order, the swapped order, and a renamed-variables control of equal cost. Questions are split
into FLIPPED (right in exactly one of orig/swap) and STABLE-RIGHT (right in both); both-wrong questions are left out.

  Q1  does the SAE code move more under order swap than under rename?         (order-specific signal)
  Q2  does the size of the code change predict which questions flip? (AUROC)   0.5 = no information
  Q3  is that at least as good as the raw residual change (no SAE)?            (does the SAE add anything)
Context row: AUROC of the model's own confidence margin. Flips are mostly low-confidence questions, so a margin AUROC well
above the SAE AUROC means the SAE tells you little beyond "the model was unsure".

DECISION RULE (fixed before running). A task counts only if it has >= 40 flipped questions and accuracy > 0.2 (chance is 0.1).
  GO  = at least one task counts AND every counting task has: AUROC(SAE swap) >= 0.60, AUROC(SAE swap) - AUROC(SAE rename) >= 0.05
        with a 95% bootstrap lower bound > 0, and AUROC(SAE swap) >= AUROC(raw swap) - 0.02.
  NO-GO = at least one task counts and the rule fails.   INCONCLUSIVE = no task counts (too few flips, or model cannot do the task).
The top-feature list is descriptive only (no correction for 16k comparisons); do not quote it as a finding.

  python3 sae_pilot.py --selftest
  python3 sae_pilot.py --tasks vartrack_d1 vartrack_d3 --n 400
"""
import argparse
import json
import os
import re

import numpy as np


def auroc(score, label):
    """P(score of a random positive > score of a random negative); ties count half."""
    score, label = np.asarray(score, float), np.asarray(label, bool)
    pos, neg = score[label], score[~label]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    order = np.argsort(np.concatenate([pos, neg]), kind="mergesort")
    allv = np.concatenate([pos, neg])[order]
    ranks = np.empty(len(allv))
    i = 0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1] == allv[i]:
            j += 1
        ranks[i:j + 1] = (i + j) / 2 + 1
        i = j + 1
    r_pos = ranks[np.argsort(order)][:len(pos)].sum()
    return float((r_pos - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def jumprelu(x, W_enc, b_enc, threshold):
    """Gemma Scope encoder: pre = x W_enc + b_enc; keep relu(pre) where pre > threshold."""
    pre = x @ W_enc + b_enc
    return (pre > threshold) * pre.clamp(min=0)


def selftest():
    import torch
    assert abs(auroc([1, 2, 3, 4], [0, 0, 1, 1]) - 1.0) < 1e-9
    assert abs(auroc([4, 3, 2, 1], [0, 0, 1, 1]) - 0.0) < 1e-9
    assert abs(auroc([1, 1, 1, 1], [0, 1, 0, 1]) - 0.5) < 1e-9
    W = torch.eye(3)
    out = jumprelu(torch.tensor([[2.0, -1.0, 0.4]]), W, torch.zeros(3), torch.tensor([1.0, 0.0, 0.5]))
    assert out.tolist() == [[2.0, 0.0, 0.0]], out
    print("sae_pilot selftest ok")


def boot_diff(a_score, b_score, flipped, n_boot=300, seed=0):
    """Bootstrap 95% interval of AUROC(a) - AUROC(b) over questions."""
    rng = np.random.default_rng(seed)
    n = len(flipped)
    diffs = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        if flipped[idx].sum() == 0 or flipped[idx].sum() == n:
            continue
        diffs.append(auroc(a_score[idx], flipped[idx]) - auroc(b_score[idx], flipped[idx]))
    return float(np.percentile(diffs, 2.5)), float(np.percentile(diffs, 97.5))


def analyse(c_o, c_s, c_r, h_o, h_s, h_r, lo_o, y, pred_o, pred_s):
    ok_o, ok_s = pred_o == y, pred_s == y
    flipped, stable = ok_o != ok_s, ok_o & ok_s
    keep = flipped | stable
    d = lambda A, B: np.linalg.norm(A - B, axis=1)
    sae_swap, sae_ren, raw_swap, raw_ren = d(c_o, c_s), d(c_o, c_r), d(h_o, h_s), d(h_o, h_r)
    srt = np.sort(lo_o, axis=1)
    margin = srt[:, -1] - srt[:, -2]
    k, f = keep, flipped[keep]
    res = dict(n=int(len(y)), flipped=int(flipped.sum()), stable_right=int(stable.sum()),
               acc_orig=float(ok_o.mean()), acc_swap=float(ok_s.mean()),
               mean_active_features=float((c_o > 0).sum(1).mean()),
               mean_code_change=dict(swap=float(sae_swap.mean()), rename=float(sae_ren.mean())),
               auroc=dict(sae_swap=auroc(sae_swap[k], f), sae_rename=auroc(sae_ren[k], f),
                          raw_swap=auroc(raw_swap[k], f), raw_rename=auroc(raw_ren[k], f), low_margin=auroc(-margin[k], f)))
    A = res["auroc"]
    counts = res["flipped"] >= 40 and res["acc_orig"] > 0.2
    res["counts"] = bool(counts)
    if counts:
        lo, hi = boot_diff(sae_swap[k], sae_ren[k], f)
        res["swap_minus_rename_ci95"] = [lo, hi]
        res["passes"] = bool(A["sae_swap"] >= 0.60 and A["sae_swap"] - A["sae_rename"] >= 0.05 and lo > 0
                             and A["sae_swap"] >= A["raw_swap"] - 0.02)
    if res["flipped"] and res["stable_right"]:
        eff = (c_s - c_o)[flipped].mean(0) - (c_s - c_o)[stable].mean(0)
        top = np.argsort(-np.abs(eff))[:10]
        res["top_features_descriptive_only"] = [dict(feature=int(i), effect=float(eff[i])) for i in top]
    return res


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", default="google/gemma-2-2b")
    ap.add_argument("--sae-repo", default="google/gemma-scope-2b-pt-res")
    ap.add_argument("--sae-layer", type=int, default=12, help="Gemma Scope numbers layers from 0 (residual AFTER block index L)")
    ap.add_argument("--width", default="16k")
    ap.add_argument("--target-l0", type=int, default=80)
    ap.add_argument("--tasks", nargs="+", default=["vartrack_d1", "vartrack_d3"])
    ap.add_argument("--n", type=int, default=400)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--out", default="sae_pilot_results")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()

    import torch
    from huggingface_hub import hf_hub_download, list_repo_files
    import model_utils as mu
    from perturb import variants
    from tasks import build_all

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    files = [f for f in list_repo_files(a.sae_repo) if f.startswith(f"layer_{a.sae_layer}/width_{a.width}/") and f.endswith("params.npz")]
    assert files, f"no SAE files under layer_{a.sae_layer}/width_{a.width}/ in {a.sae_repo}"
    best = min(files, key=lambda f: abs(int(re.search(r"average_l0_(\d+)", f).group(1)) - a.target_l0))
    print("SAE file:", best, flush=True)
    p = np.load(hf_hub_download(a.sae_repo, best))
    W_enc, b_enc, thr = (torch.tensor(p[k], dtype=torch.float32, device=dev) for k in ("W_enc", "b_enc", "threshold"))

    tok, model = mu.load(a.model, None, dev, torch.bfloat16 if dev == "cuda" else torch.float32)
    d_model = model.config.hidden_size
    assert W_enc.shape[0] == d_model, f"SAE input size {W_enc.shape[0]} != model width {d_model}"
    bos = tok.bos_token or ""
    layer = a.sae_layer + 1            # mu layers count blocks from 1 (output of block index l-1)
    all_items = build_all(a.n, a.seed, shots=2, layout="blocked")
    summary = dict(model=a.model, sae_file=best, sae_layer=a.sae_layer, tasks={})
    for task in a.tasks:
        items = all_items[task]
        cids = mu.candidate_ids(tok, items[0]["candidates"])
        vs = [variants(it["prompt"], seed=a.seed * 100003 + i) for i, it in enumerate(items)]
        y = np.array([it["label"] for it in items])
        ids0 = tok(bos + vs[0]["orig"], add_special_tokens=False)["input_ids"]
        assert ids0[0] == tok.bos_token_id, "BOS token was not prepended; Gemma needs it"
        print(f"--- {task}: first token is BOS, last tokens: {tok.convert_ids_to_tokens(ids0[-6:])}", flush=True)

        def run(key):
            lo, acts = mu.run(tok, model, [bos + v[key] for v in vs], cids, read_layers=[layer],
                              batch_size=a.batch_size, device=dev)
            h = acts[layer].to(dev).float()
            with torch.no_grad():
                code = jumprelu(h, W_enc, b_enc, thr)
            return lo.numpy(), h.cpu().numpy(), code.cpu().numpy()

        lo_o, h_o, c_o = run("orig")
        lo_s, h_s, c_s = run("swap")
        _, h_r, c_r = run("rename")
        res = analyse(c_o, c_s, c_r, h_o, h_s, h_r, lo_o, y, lo_o.argmax(-1), lo_s.argmax(-1))
        summary["tasks"][task] = res
        print(task, json.dumps(res, indent=2), flush=True)
    counting = [r for r in summary["tasks"].values() if r["counts"]]
    summary["decision"] = ("INCONCLUSIVE" if not counting else "GO" if all(r["passes"] for r in counting) else "NO-GO")
    print("DECISION:", summary["decision"])
    os.makedirs(a.out, exist_ok=True)
    json.dump(summary, open(os.path.join(a.out, f"{a.model.split('/')[-1]}__L{a.sae_layer}.json"), "w"), indent=2)


if __name__ == "__main__":
    main()
