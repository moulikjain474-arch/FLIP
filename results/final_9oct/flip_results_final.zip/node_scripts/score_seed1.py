import glob, json, os, sys
from math import comb

def mcnemar(a, b):
    n10 = sum(1 for x, y in zip(a, b) if x and not y)
    n01 = sum(1 for x, y in zip(a, b) if y and not x)
    n = n10 + n01
    if n == 0:
        return n10, n01, 1.0
    k = min(n10, n01)
    p = min(1.0, 2 * sum(comb(n, i) for i in range(k + 1)) / 2 ** n)
    return n10, n01, p

d = sys.argv[1] if len(sys.argv) > 1 else "/scratch/flip_out/fullday/perturb_seed1_families"
print("model | task | n | orig | swap | flip_swap | ens_swap | ens_rename | swap-rename | swap_only/rename_only | McNemar p")
for f in sorted(glob.glob(os.path.join(d, "*.json"))):
    r = json.load(open(f))
    name = os.path.basename(f).split("__")[0]
    for t, e in r["tasks"].items():
        s = e["summary"]
        a, b, p = mcnemar(e["ens_correct"]["swap"], e["ens_correct"]["rename"])
        print("%s | %s | %d | %.3f | %.3f | %.3f | %.3f | %.3f | %+.3f | %d/%d | %.3g" % (
            name, t, s["n"], s["acc_orig"], s["acc_swap"], s["flip_swap"],
            s["acc_ens_swap"], s["acc_ens_rename"], s["acc_ens_swap"] - s["acc_ens_rename"], a, b, p))
