"""Chain-probe accuracy (best layer, with its shuffled-label control) by training seed and step.
  python3 seed_onset.py --dir $PERSIST/fullday/onset_410m_seeds
Readable = best-layer accuracy clearly above the shuffled control. Exploratory (added 9 Oct, after results were seen)."""
import argparse, glob, json, os, re
ap = argparse.ArgumentParser(); ap.add_argument("--dir", required=True); a = ap.parse_args()
rows = {}
for f in sorted(glob.glob(os.path.join(a.dir, "*", "*.json"))):
    d = json.load(open(f)); m = os.path.basename(os.path.dirname(f))
    step = int(re.search(r"step(\d+)", d["revision"]).group(1))
    for t, r in d["tasks"].items():
        ls = r.get("layers", {})
        if not ls: continue
        best = max(ls.items(), key=lambda kv: kv[1]["acc"])
        rows.setdefault((t, m), {})[step] = (best[1]["acc"], best[1]["acc_shuffled"], best[0])
steps = sorted({s for v in rows.values() for s in v})
for t in sorted({k[0] for k in rows}):
    print(f"\n{t}   best-layer probe acc (shuffled control) by step")
    print("model".ljust(22) + "".join(f"{s:>16}" for s in steps))
    for (tt, m), v in sorted(rows.items()):
        if tt != t: continue
        print(m.ljust(22) + "".join((f"{v[s][0]:.3f} ({v[s][1]:.2f})".rjust(16) if s in v else "-".rjust(16)) for s in steps))
