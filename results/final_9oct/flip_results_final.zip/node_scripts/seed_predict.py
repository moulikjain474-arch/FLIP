"""Can the early checkpoints of a run predict which way it ends? (exploratory; uses results you already have, no GPU)

Across the nine 410M training runs (default + seeds 1-9 minus the suspect one), compare each run's first-or-last habit
(picks_later) at an early step with the same run's habit at the final step 143000: Spearman rank correlation, and how many runs
sit on the same side of 0.5 early and at the end. With 9 runs this is a small-n result; the permutation p-value is exact for
the rank correlation and is reported as such. Motivated by the "predict outcomes from early training signals" level in
Biderman et al.'s learning-dynamics position paper.

  python3 seed_predict.py --dir $PERSIST/fullday/position           # folder that holds one subfolder per model
  python3 seed_predict.py --selftest
"""
import argparse
import glob
import itertools
import json
import os
import re

import numpy as np


def ranks(x):
    x = np.asarray(x, float)
    order = np.argsort(x, kind="mergesort")
    r = np.empty(len(x))
    i = 0
    while i < len(x):
        j = i
        while j + 1 < len(x) and x[order[j + 1]] == x[order[i]]:
            j += 1
        r[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return r


def spearman(a, b):
    ra, rb = ranks(a), ranks(b)
    if ra.std() == 0 or rb.std() == 0:
        return float("nan")
    return float(np.corrcoef(ra, rb)[0, 1])


def exact_p(a, b, max_exact=9, draws=200000, seed=0):
    """Two-sided permutation p-value of the Spearman correlation (all permutations if n <= 9, else random draws)."""
    n = len(a)
    ra, rb = ranks(a), ranks(b)
    if ra.std() == 0 or rb.std() == 0:
        return float("nan")
    za = (ra - ra.mean()) / ra.std()
    zb = (rb - rb.mean()) / rb.std()
    obs = abs(float(za @ zb) / n)
    if n <= max_exact:
        perms = np.array(list(itertools.permutations(range(n))), dtype=np.int16)
    else:
        rng = np.random.default_rng(seed)
        perms = np.argsort(rng.random((draws, n)), axis=1)
    r = (zb[perms] @ za) / n
    return float((np.abs(r) >= obs - 1e-9).mean())


def load(root, task):
    """{model: {step: picks_later}} for one task."""
    out = {}
    for f in glob.glob(os.path.join(root, "*", "*__step*__blocked.json")):
        m = re.search(r"__step(\d+)__", f)
        model = os.path.basename(os.path.dirname(f))
        try:
            v = json.load(open(f))["tasks"][task]["picks_later"]["rate"]
        except (KeyError, ValueError):
            continue
        if v is not None:
            out.setdefault(model, {})[int(m.group(1))] = v
    return out


def report(root, tasks=("vartrack_d2", "vartrack_d3"), early=(4000, 8000, 32000), final=143000):
    for task in tasks:
        d = load(root, task)
        print(f"\n== {task}: {len(d)} runs found")
        for s in early:
            models = sorted(m for m, v in d.items() if s in v and final in v)
            if len(models) < 5:
                print(f"  step {s}: only {len(models)} runs with both steps; skipped")
                continue
            a = [d[m][s] for m in models]
            b = [d[m][final] for m in models]
            same = sum((x > 0.5) == (y > 0.5) for x, y in zip(a, b))
            print(f"  step {s} vs {final}: n={len(models)}  spearman={spearman(a, b):+.2f}  exact p={exact_p(a, b):.3f}  "
                  f"same side of 0.5: {same}/{len(models)}")


def selftest():
    a = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    assert abs(spearman(a, a) - 1) < 1e-9 and abs(spearman(a, a[::-1]) + 1) < 1e-9
    assert exact_p(a, a) < 0.001            # 2/9! = 5.5e-6
    assert exact_p(a, [0.5, 0.1, 0.9, 0.3, 0.7, 0.2, 0.8, 0.4, 0.6]) > 0.2
    assert spearman([1, 1, 2, 3], [1, 2, 3, 4]) > 0
    print("seed_predict selftest ok")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.dir:
        raise SystemExit("give --dir")
    report(a.dir)


if __name__ == "__main__":
    main()
