"""One stability table for the paper: the order effect (picks_later) across every setting you already ran. No GPU.

Reads every position_test result JSON under --root (files named <model>__<revision>__<layout>.json), and prints, for each task,
one row per (model, checkpoint, layout): rate, 95% CI, n, and whether the CI excludes 0.5. Then a one-line tally per task:
how many settings lean "later", how many "earlier", how many are inconclusive. Also writes stability_table.csv.
A result that holds across seeds, layouts, depths and families is the point; a setting that flips direction is a finding to report.

  python3 stability_table.py --root $PERSIST/fullday --final-only      # final checkpoints only (step143000 / main)
  python3 stability_table.py --root $PERSIST/fullday                   # every checkpoint (long)
  python3 stability_table.py --selftest
"""
import argparse
import csv
import glob
import json
import os
import re
import tempfile


def rows_from(root, final_only=False, want_layout=None):
    out = []
    for f in glob.glob(os.path.join(root, "**", "*__*__*.json"), recursive=True):
        base = os.path.basename(f)[:-5]
        parts = base.split("__")
        if len(parts) < 3:
            continue
        try:
            d = json.load(open(f))
            tasks = d["tasks"]
            if not isinstance(tasks, dict):
                continue
        except (ValueError, KeyError, TypeError, OSError):
            continue
        model = d.get("model") if isinstance(d.get("model"), str) else parts[-3]
        rev = d.get("revision") if isinstance(d.get("revision"), str) else parts[-2]
        layout = d.get("layout") if isinstance(d.get("layout"), str) else parts[-1]
        if want_layout and layout != want_layout:
            continue
        if final_only and not (rev in ("main", "step143000") or re.fullmatch(r"step143000", rev)):
            continue
        for t, v in tasks.items():
            pl = v.get("picks_later") if isinstance(v, dict) else None
            if not isinstance(pl, dict) or not isinstance(pl.get("rate"), (int, float)):
                continue
            ci = pl.get("ci95")
            if not (isinstance(ci, (list, tuple)) and len(ci) == 2):
                ci = [None, None]
            out.append(dict(task=t, model=model, revision=rev, layout=layout, n=pl.get("n"), rate=pl["rate"],
                            lo=ci[0], hi=ci[1]))
    return sorted(out, key=lambda r: (r["task"], r["model"], r["revision"], r["layout"]))


def verdict(r):
    if r["lo"] is None or r["hi"] is None:
        return "?"
    if r["lo"] > 0.5:
        return "later"
    if r["hi"] < 0.5:
        return "earlier"
    return "inconclusive"


def report(rows, csv_path="stability_table.csv"):
    last = None
    tally = {}
    for r in rows:
        if r["task"] != last:
            if last is not None:
                print("   tally:", tally[last])
            print(f"\n== {r['task']}")
            print(f"  {'model':34s} {'revision':14s} {'layout':12s} {'n':>5s} {'rate':>6s}  95% CI          verdict")
            last = r["task"]
        v = verdict(r)
        tally.setdefault(r["task"], {}).setdefault(v, 0)
        tally[r["task"]][v] += 1
        ci = f"[{r['lo']:.2f}, {r['hi']:.2f}]" if r["lo"] is not None else "n/a"
        print(f"  {r['model'][:34]:34s} {r['revision']:14s} {r['layout']:12s} {str(r['n']):>5s} {r['rate']:6.2f}  {ci:15s} {v}")
    if last is not None:
        print("   tally:", tally[last])
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["task", "model", "revision", "layout", "n", "rate", "lo", "hi", "verdict"])
        w.writeheader()
        for r in rows:
            w.writerow({**r, "verdict": verdict(r)})
    print(f"\nwrote {csv_path} ({len(rows)} rows)")


def selftest():
    with tempfile.TemporaryDirectory() as tmp:
        os.makedirs(os.path.join(tmp, "m"))
        for rev, lay, rate, lo, hi in [("step143000", "blocked", 0.7, 0.6, 0.8), ("step4000", "blocked", 0.5, 0.4, 0.6),
                                       ("step143000", "interleaved", 0.3, 0.2, 0.4)]:
            json.dump(dict(model="m", revision=rev, layout=lay,
                           tasks={"vartrack_d2": dict(picks_later=dict(k=1, n=100, rate=rate, ci95=[lo, hi]))}),
                      open(os.path.join(tmp, "m", f"m__{rev}__{lay}.json"), "w"))
        rows = rows_from(tmp)
        assert len(rows) == 3 and [verdict(r) for r in rows].count("inconclusive") == 1
        assert len(rows_from(tmp, final_only=True)) == 2
        report(rows, os.path.join(tmp, "t.csv"))
        assert os.path.exists(os.path.join(tmp, "t.csv"))
    print("stability_table selftest ok")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root")
    ap.add_argument("--final-only", action="store_true")
    ap.add_argument("--layout", choices=("blocked", "interleaved"), default=None)
    ap.add_argument("--csv", default="stability_table.csv")
    a = ap.parse_args()
    if not a.root:
        return selftest()
    report(rows_from(a.root, a.final_only, a.layout), a.csv)


if __name__ == "__main__":
    main()
