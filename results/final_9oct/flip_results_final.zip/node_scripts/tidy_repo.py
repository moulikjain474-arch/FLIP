"""Tidy the submission tree without breaking provenance (added 9 Oct). DRY RUN by default; nothing moves unless you pass --apply.

  python3 tidy_repo.py --root .             # shows what would move and what refers to it
  python3 tidy_repo.py --root . --apply     # moves it and writes unused/README.md

What moves (never run, or superseded and already applied):
  sae_pilot.py                         parked: Gemma-2-2B access was never granted, so it was never run
  patch_steer_stage.py, patch_plant_rand.py, patch_model_utils.py
                                       one-time edits that are already applied; steer_stage.py / model_utils.py contain the change
What does NOT move, on purpose:
  value_probe.py, run_value_probe.sh   they produced a REPORTED negative result (the value probe was uninformative, at the
                                       random-init baseline). Moving them would break run_step0.sh and check_all.sh and the record of
                                       how that result was made. They are listed in unused/README.md as 'kept in place'.
  every run_*.sh and register_*.py     each produced results or edited EXPERIMENTS.md; they are the provenance. Use list_runners.py
                                       for an index instead of deleting them.
"""
import argparse
import os
import shutil

MOVE = {
    "sae_pilot.py": "parked: Gemma-2-2B access was never granted, so this pilot was never run (decision rule is in its docstring)",
    "patch_steer_stage.py": "one-time edit, already applied to steer_stage.py (exploratory options P3/P4)",
    "patch_plant_rand.py": "one-time edit, already applied to steer_stage.py (random-subspace plant control, C24)",
    "patch_model_utils.py": "one-time edit, already applied to model_utils.py (load straight onto the GPU)",
}
KEEP = {
    "value_probe.py": "kept in place: ran at several checkpoints; result (uninformative, near the random-init baseline) is reported",
    "run_value_probe.sh": "kept in place: started and stopped early; its partial output is not used, the step-0 baseline comes from run_step0.sh",
}


def find(root, name):
    for dp, dn, fn in os.walk(root):
        if "unused" in dp.split(os.sep):
            continue
        if name in fn:
            return os.path.join(dp, name)
    return None


def referrers(root, name):
    hits = []
    for dp, dn, fn in os.walk(root):
        if ".git" in dp.split(os.sep) or "unused" in dp.split(os.sep):
            continue
        for f in fn:
            if f.endswith((".py", ".sh", ".md", ".txt")) and f != name:
                try:
                    if name in open(os.path.join(dp, f), errors="ignore").read():
                        hits.append(os.path.join(dp, f))
                except OSError:
                    pass
    return hits


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=".")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    dest = os.path.join(a.root, "unused")
    lines = ["# unused/", "", "Files kept for the record that are not part of the results pipeline.", ""]
    for name, why in MOVE.items():
        src = find(a.root, name)
        if not src:
            print(f"- {name}: not found (already moved or not in this tree)")
            continue
        refs = referrers(a.root, name)
        print(f"- {name}: would move to unused/   referenced by: {', '.join(refs) if refs else 'nothing'}")
        lines.append(f"- `{name}`: {why}")
        if a.apply:
            os.makedirs(dest, exist_ok=True)
            shutil.move(src, os.path.join(dest, name))
    lines += ["", "Kept in place on purpose:", ""] + [f"- `{n}`: {w}" for n, w in KEEP.items()]
    if a.apply:
        os.makedirs(dest, exist_ok=True)
        open(os.path.join(dest, "README.md"), "w").write("\n".join(lines) + "\n")
        print("moved; wrote unused/README.md. Check the 'referenced by' lines above and fix any that point at a moved file.")
    else:
        print("dry run only. Add --apply to move.")


if __name__ == "__main__":
    main()
