"""Is the VALUE decodable at the last token, and does that match when the model uses it? (rung 2, replacement for the chain-label probe)

The chain-label probe in chain_probe.py scored 1.000 at every checkpoint (even at step 4000, near chance), so it is reading
something visible in the prompt and cannot show emergence. This probe asks for something that has to be computed:
  answer      which digit the queried variable ends up with (10 classes)
  distractor  which digit the OTHER chain ends up with
Both are read from the last-token residual stream at a few layers, cross-validated linear probe, settings fixed in advance
(C=0.1, 5 folds, standardised). Reference points printed with each score: chance (majority class), a shuffled-label probe,
and layer 1 (a layer that has barely seen the context: if it already scores high, the label is visible in the prompt).
Exploratory (9 Oct, after the chain-label probe saturated).

  python3 value_probe.py --model EleutherAI/pythia-6.9b --step 4000 --out value_probe_results
  python3 value_probe.py --report value_probe_results          # one table across checkpoints
  python3 value_probe.py --selftest
"""
import argparse
import glob
import json
import os
import re

import numpy as np


def cv_acc(X, y, seed=0):
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import StratifiedKFold
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    y = np.asarray(y)
    keep = np.isin(y, [c for c in np.unique(y) if (y == c).sum() >= 5])    # drop classes too rare to stratify
    X, y = X[keep], y[keep]
    correct = np.zeros(len(y), bool)
    for tr, te in StratifiedKFold(5, shuffle=True, random_state=seed).split(X, y):
        clf = make_pipeline(StandardScaler(), LogisticRegression(C=0.1, max_iter=500))
        clf.fit(X[tr], y[tr])
        correct[te] = clf.predict(X[te]) == y[te]
    return float(correct.mean()), float(np.bincount(y).max() / len(y))


def selftest():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 10, 400)
    X_sig = np.eye(10)[y] * 3 + rng.normal(size=(400, 10))
    acc, chance = cv_acc(X_sig, y)
    assert acc > 0.8 and chance < 0.2, (acc, chance)
    acc0, _ = cv_acc(rng.normal(size=(400, 10)), y)
    assert acc0 < 0.25, acc0
    acc_s, _ = cv_acc(X_sig, rng.permutation(y))
    assert acc_s < 0.25, acc_s
    print("value_probe selftest ok")


def report(root):
    rows = []
    for f in glob.glob(os.path.join(root, "*.json")):
        m = re.search(r"step(\d+)", f)
        js = json.load(open(f))
        for t, r in js["tasks"].items():
            best = {}
            for lab in ("answer", "distractor"):
                ls = {int(l): v[lab] for l, v in r["layers"].items()}
                lb = max(ls, key=lambda k: ls[k])
                best[lab] = (ls[lb], lb, r["layers"][str(lb)][lab + "_shuffled"], r["layers"][str(min(int(k) for k in r["layers"]))][lab])
            rows.append((int(m.group(1)) if m else -1, t, r["natural_acc"], best, r["chance_answer"]))
    print("step | task | model acc | answer probe (best layer; shuffled; layer-1) | distractor probe (same) | chance")
    for s, t, na, b, ch in sorted(rows):
        a, d = b["answer"], b["distractor"]
        print(f"{s} | {t} | {na:.3f} | {a[0]:.3f} @L{a[1]}; {a[2]:.3f}; {a[3]:.3f} | {d[0]:.3f} @L{d[1]}; {d[2]:.3f}; {d[3]:.3f} | {ch:.2f}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--revision", default=None)
    ap.add_argument("--tasks", nargs="+", default=["vartrack_d1", "vartrack_d3"])
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--layers", type=int, nargs="+", default=None)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--out", default="value_probe_results")
    ap.add_argument("--report", default=None)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if args.report:
        return report(args.report)
    if not args.model or (args.step is None) == (args.revision is None):
        raise SystemExit("give --model and exactly one of --step or --revision")
    revision = args.revision or f"step{args.step}"

    import torch
    import model_utils as mu
    from steer_stage import distractor_index
    from tasks import build_all

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = (torch.float16 if "pythia" in args.model else torch.bfloat16) if dev == "cuda" else torch.float32
    tok, model = mu.load(args.model, revision, dev, dtype)
    L = mu.n_layers(model)
    layers = args.layers or sorted({1, L // 4, L // 2, (3 * L) // 4, L})
    items_all = build_all(args.n, args.seed, shots=2, layout="blocked")
    out = dict(model=args.model, revision=revision, n_layers=L, layers=layers, tasks={})
    rng = np.random.default_rng(args.seed)
    for t in args.tasks:
        items = items_all[t]
        prompts = [it["prompt"] for it in items]
        cids = mu.candidate_ids(tok, items[0]["candidates"])
        logits, acts = mu.run(tok, model, prompts, cids, read_layers=layers, batch_size=args.batch_size, device=dev)
        ans = np.array([it["label"] for it in items])
        dis = np.array([distractor_index(it) for it in items])
        res = dict(n=len(items), natural_acc=float((logits.argmax(-1).numpy() == ans).mean()), layers={})
        for l in layers:
            X = acts[l].numpy()
            a, ca = cv_acc(X, ans)
            d, cd = cv_acc(X, dis)
            res["layers"][l] = dict(answer=a, distractor=d, answer_shuffled=cv_acc(X, rng.permutation(ans))[0],
                                    distractor_shuffled=cv_acc(X, rng.permutation(dis))[0])
            res["chance_answer"], res["chance_distractor"] = ca, cd
            print(t, "layer", l, res["layers"][l], flush=True)
        out["tasks"][t] = res
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, f"{args.model.split('/')[-1]}__{revision}.json"), "w") as f:
        json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
